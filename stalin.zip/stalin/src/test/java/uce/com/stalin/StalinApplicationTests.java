package uce.com.stalin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StalinApplicationTests {

	@Test
	void contextLoads() {
	}

}
